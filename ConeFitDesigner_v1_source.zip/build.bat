
@echo off
setlocal

REM ==== Create venv ====
if not exist .venv (
  py -3 -m venv .venv
)
call .venv\Scripts\activate

REM ==== Install deps ====
python -m pip install --upgrade pip
pip install pyqt5 reportlab pyinstaller

REM ==== Generate manual.pdf ====
python tools\generate_manual.py

REM ==== PyInstaller build ====
REM add data: sample json and manual.pdf
pyinstaller -F -w ^
  --name ConeFitDesigner ^
  --add-data "src\data\sample_input.json;data" ^
  --add-data "src\resources\manual.pdf;." ^
  src\main.py

echo.
echo Build finished. EXE at: dist\ConeFitDesigner.exe
echo.

endlocal
pause

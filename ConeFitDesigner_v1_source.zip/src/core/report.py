
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas
from reportlab.lib.units import mm
from reportlab.lib import colors

def gen_pdf(path, meta, geom, tol, sim):
    c = canvas.Canvas(path, pagesize=A4)
    W, H = A4
    x, y = 20*mm, H-20*mm

    def ln(txt="", dy=6*mm):
        nonlocal y
        c.drawString(x, y, txt)
        y -= dy

    c.setFont("Helvetica-Bold", 14)
    ln("圆锥配合设计计算报告")
    c.setFont("Helvetica", 10)
    ln(f"项目: {meta.get('project','')}   日期: {meta.get('date','')}   版本: {meta.get('version','1.0')}")

    ln("—— 几何参数 ———", 7*mm)
    for k in ("D","d","L","C","alpha"):
        ln(f"{k}: {geom.get(k)}")

    ln("—— 公差/接触评估 ———", 7*mm)
    ln(f"配合类型: {tol.get('fit_type','-')}")
    ln(f"参考截面孔径范围: {tol.get('hole_min')} ~ {tol.get('hole_max')}")
    ln(f"参考截面轴径范围: {tol.get('shaft_min')} ~ {tol.get('shaft_max')}")
    ln(f"配合判定: {tol.get('fit_decision','-')}")
    ln(f"角度公差(全角, deg): ±{tol.get('angle_tol_deg','-')}")
    ln(f"建议角度公差(全角, deg): ±{tol.get('angle_tol_suggest_deg','-')}")

    ln("—— 配合模拟 ———", 7*mm)
    ln(f"预测错口量(末端缝隙, mm): {sim.get('predicted_gap')}")
    ln(f"接触率(估计): {round(sim.get('contact_ratio',0)*100,1)}%")
    ln(f"状态: {sim.get('status','-')}")

    c.showPage()
    c.save()

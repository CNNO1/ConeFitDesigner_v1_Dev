
import math

def safe_float(v, default=None):
    try:
        return float(v)
    except (TypeError, ValueError):
        return default

def ratio_to_conicity(ratio_str):
    """
    Convert a ratio string like '1:20' to conicity C = (D-d)/L = 1/20.
    Returns float or None.
    """
    if not ratio_str:
        return None
    s = str(ratio_str).strip().lower().replace(' ', '')
    if ':' in s:
        a, b = s.split(':', 1)
        a = safe_float(a, None)
        b = safe_float(b, None)
        if a and b and b != 0:
            return a / b
    # allow pure number (e.g., 0.05 meaning (D-d)/L)
    f = safe_float(s, None)
    return f

def conicity_to_ratio(C):
    if C is None or C == 0:
        return None
    # return as "1:N" style if C < 1 else "M:1"
    if abs(C) < 1:
        return f"1:{round(1.0/abs(C), 6)}"
    else:
        return f"{round(abs(C), 6)}:1"

def angle_from_conicity(C):
    """
    Given conicity C = (D-d)/L, half-angle alpha/2 satisfies tan(alpha/2) = C/2
    Returns full angle alpha in degrees.
    """
    if C is None:
        return None
    half = math.degrees(math.atan(C/2.0))
    return 2.0 * half

def conicity_from_angle(alpha_deg):
    """
    Given full apex angle alpha (deg), C = 2*tan(alpha/2)
    """
    if alpha_deg is None:
        return None
    return 2.0 * math.tan(math.radians(alpha_deg/2.0))

def solve_geometry(D=None, d=None, L=None, C=None, alpha=None):
    """
    Solve cone geometry. Accepts any two/three among D, d, L, C, alpha (deg).
    Returns dict with D, d, L, C, alpha.
    """
    # normalize inputs
    D = safe_float(D, None)
    d = safe_float(d, None)
    L = safe_float(L, None)
    C = safe_float(C, None)
    alpha = safe_float(alpha, None)

    # if alpha given, compute C
    if alpha is not None and C is None:
        C = conicity_from_angle(alpha)

    # if C given but alpha not, compute alpha
    if C is not None and alpha is None:
        alpha = angle_from_conicity(C)

    # If D,d,L present, compute C/alpha
    if D is not None and d is not None and L is not None and L != 0:
        C = (D - d) / L
        alpha = angle_from_conicity(C)

    # If D,L,C present -> d
    if D is not None and L is not None and C is not None:
        d = D - C * L

    # If d,L,C present -> D
    if d is not None and L is not None and C is not None:
        D = d + C * L

    # If D,d,C present -> L
    if D is not None and d is not None and C not in (None, 0):
        L = (D - d) / C

    # If D,d,alpha present -> L
    if D is not None and d is not None and alpha is not None:
        C = conicity_from_angle(alpha)
        if C not in (None, 0):
            L = (D - d) / C

    # sanity checks
    result = dict(D=D, d=d, L=L, C=C, alpha=alpha)
    return result

# ---------- Tolerance & contact estimation ----------

def contact_estimation(L, delta_alpha_deg=None, max_gap_allow=None):
    """
    Very simple heuristic:
    - Assume angle mismatch delta_alpha (full angle, deg). Half-angle mismatch = delta_alpha/2.
    - Linearized 'mouth opening' (gap) over length L: gap ≈ 2 * L * tan(Δ(half)/1) ~ L * Δalpha(rad)
      Using small-angle: gap ≈ L * (Δalpha_deg * pi/180)
    Return dict with 'predicted_gap' at the far end and 'contact_ratio' ≈ 1 - gap/L_clip
    """
    L = safe_float(L, 0.0) or 0.0
    if L <= 0:
        return {"predicted_gap": None, "contact_ratio": None}

    da = safe_float(delta_alpha_deg, 0.0) or 0.0
    gap = L * (abs(da) * math.pi/180.0)  # mm if angle small and cone slope ~ 1? treat as heuristic length gap
    # contact ratio clamp
    contact_ratio = max(0.0, min(1.0, 1.0 - gap / max(L, 1e-9)))
    status = "OK"
    if max_gap_allow is not None and gap > max_gap_allow:
        status = "EXCEED"
    return {"predicted_gap": gap, "contact_ratio": contact_ratio, "status": status}

def suggest_angle_tolerance(L, max_gap_allow):
    """
    Invert simple model: gap ≈ L * Δalpha(rad) <= max_gap
    => Δalpha(rad) <= max_gap / L, in deg = ... * 180/pi (full angle tolerance)
    """
    L = safe_float(L, None)
    mg = safe_float(max_gap_allow, None)
    if not L or not mg or L <= 0 or mg <= 0:
        return None
    deg = (mg / L) * 180.0 / math.pi
    return deg  # full-angle tolerance in degrees

def clearance_fit_check(Dh_min, Dh_max, Ds_min, Ds_max):
    """
    Simple fit decision at a reference section between a hole (h) and shaft (s).
    Return 'clearance', 'interference', or 'transition' based on extreme overlap.
    """
    # hole range [Dh_min, Dh_max], shaft [Ds_min, Ds_max]
    if Dh_min is None or Dh_max is None or Ds_min is None or Ds_max is None:
        return None
    if Ds_max <= Dh_min:
        return "clearance"
    elif Ds_min >= Dh_max:
        return "interference"
    else:
        return "transition"

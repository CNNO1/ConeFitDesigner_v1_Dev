
import sys, os, json
from PyQt5 import QtWidgets, QtCore
from core.calcs import solve_geometry, ratio_to_conicity, conicity_to_ratio, angle_from_conicity, contact_estimation, suggest_angle_tolerance, clearance_fit_check
from core.report import gen_pdf
from datetime import datetime

APP_TITLE = "Cone Fit Designer (圆锥配合设计计算) - v1.0"

class MainWindow(QtWidgets.QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle(APP_TITLE)
        self.resize(980, 640)

        tabs = QtWidgets.QTabWidget()
        self.setCentralWidget(tabs)

        # Geometry tab
        self.tab_geom = QtWidgets.QWidget()
        tabs.addTab(self.tab_geom, "几何计算")
        self._init_geom_tab()

        # Tolerance tab
        self.tab_tol = QtWidgets.QWidget()
        tabs.addTab(self.tab_tol, "公差与接触")
        self._init_tol_tab()

        # Report tab
        self.tab_report = QtWidgets.QWidget()
        tabs.addTab(self.tab_report, "报告导出")
        self._init_report_tab()

        # Menu
        self._init_menu()

    def _init_menu(self):
        mb = self.menuBar()
        m_file = mb.addMenu("文件")
        act_load = QtWidgets.QAction("加载示例JSON", self)
        act_load.triggered.connect(self.load_sample)
        m_file.addAction(act_load)

        act_quit = QtWidgets.QAction("退出", self)
        act_quit.triggered.connect(self.close)
        m_file.addAction(act_quit)

        m_help = mb.addMenu("帮助")
        act_manual = QtWidgets.QAction("打开说明文档（构建后PDF）", self)
        act_manual.triggered.connect(self.open_manual)
        m_help.addAction(act_manual)

        act_about = QtWidgets.QAction("关于", self)
        act_about.triggered.connect(lambda: QtWidgets.QMessageBox.information(self, "关于", APP_TITLE + "\n设计与开发：你与AI"))
        m_help.addAction(act_about)

    def open_manual(self):
        # look for manual.pdf packaged next to exe or in resources
        candidates = [
            os.path.join(os.path.dirname(sys.executable if getattr(sys, 'frozen', False) else __file__), "manual.pdf"),
            os.path.join(os.path.dirname(__file__), "resources", "manual.pdf"),
            os.path.join(os.getcwd(), "manual.pdf"),
        ]
        for p in candidates:
            if os.path.exists(p):
                QtGui = __import__("PyQt5.QtGui", fromlist=["QtGui"]).QtGui
                QtCore = __import__("PyQt5.QtCore", fromlist=["QtCore"]).QtCore
                QtGui.QDesktopServices.openUrl(QtCore.QUrl.fromLocalFile(p))
                return
        QtWidgets.QMessageBox.warning(self, "提示", "未找到 manual.pdf。请先运行 tools/generate_manual.py 生成PDF。")

    # ---------- Geometry Tab ----------
    def _init_geom_tab(self):
        layout = QtWidgets.QGridLayout(self.tab_geom)

        self.ed_D = QtWidgets.QLineEdit(); self.ed_d = QtWidgets.QLineEdit()
        self.ed_L = QtWidgets.QLineEdit(); self.ed_ratio = QtWidgets.QLineEdit()
        self.ed_alpha = QtWidgets.QLineEdit()

        layout.addWidget(QtWidgets.QLabel("大端直径 D (mm)"), 0, 0); layout.addWidget(self.ed_D, 0, 1)
        layout.addWidget(QtWidgets.QLabel("小端直径 d (mm)"), 1, 0); layout.addWidget(self.ed_d, 1, 1)
        layout.addWidget(QtWidgets.QLabel("锥长 L (mm)"), 2, 0); layout.addWidget(self.ed_L, 2, 1)
        layout.addWidget(QtWidgets.QLabel("锥度比 (如 1:20 或 0.05)"), 3, 0); layout.addWidget(self.ed_ratio, 3, 1)
        layout.addWidget(QtWidgets.QLabel("全顶角 α (deg)"), 4, 0); layout.addWidget(self.ed_alpha, 4, 1)

        self.btn_calc_geom = QtWidgets.QPushButton("计算几何")
        self.btn_calc_geom.clicked.connect(self.on_calc_geom)
        layout.addWidget(self.btn_calc_geom, 5, 0, 1, 2)

        self.txt_geom = QtWidgets.QTextEdit(); self.txt_geom.setReadOnly(True)
        layout.addWidget(self.txt_geom, 6, 0, 1, 2)

    def on_calc_geom(self):
        D = self.ed_D.text().strip() or None
        d = self.ed_d.text().strip() or None
        L = self.ed_L.text().strip() or None
        ratio = self.ed_ratio.text().strip() or None
        alpha = self.ed_alpha.text().strip() or None

        C = ratio_to_conicity(ratio) if ratio else None
        alpha_val = float(alpha) if alpha else None

        res = solve_geometry(D=D, d=d, L=L, C=C, alpha=alpha_val)
        # Compose ratio string
        ratio_str = conicity_to_ratio(res.get("C")) if res.get("C") is not None else None

        lines = []
        lines.append("— 计算结果 —")
        for k in ("D","d","L","C","alpha"):
            lines.append(f"{k} = {res.get(k)}")
        lines.append(f"锥度比(格式化): {ratio_str}")
        self.txt_geom.setPlainText("\n".join(lines))

        # save for other tabs
        self.geom_cache = res

    # ---------- Tolerance Tab ----------
    def _init_tol_tab(self):
        layout = QtWidgets.QGridLayout(self.tab_tol)

        # Inputs
        self.cb_fit = QtWidgets.QComboBox()
        self.cb_fit.addItems(["clearance(间隙)", "interference(过盈)", "transition(过渡)"])

        self.ed_hole_min = QtWidgets.QLineEdit(); self.ed_hole_max = QtWidgets.QLineEdit()
        self.ed_shaft_min = QtWidgets.QLineEdit(); self.ed_shaft_max = QtWidgets.QLineEdit()
        self.ed_angle_tol = QtWidgets.QLineEdit()
        self.ed_length = QtWidgets.QLineEdit()
        self.ed_max_gap_allow = QtWidgets.QLineEdit()

        r = 0
        layout.addWidget(QtWidgets.QLabel("配合类型"), r, 0); layout.addWidget(self.cb_fit, r, 1); r+=1
        layout.addWidget(QtWidgets.QLabel("孔最小/最大 (mm)"), r, 0); 
        layout.addWidget(self.ed_hole_min, r, 1); layout.addWidget(self.ed_hole_max, r, 2); r+=1
        layout.addWidget(QtWidgets.QLabel("轴最小/最大 (mm)"), r, 0); 
        layout.addWidget(self.ed_shaft_min, r, 1); layout.addWidget(self.ed_shaft_max, r, 2); r+=1
        layout.addWidget(QtWidgets.QLabel("角度公差(全角, ±deg)"), r, 0); layout.addWidget(self.ed_angle_tol, r, 1); r+=1
        layout.addWidget(QtWidgets.QLabel("有效锥长 L (mm)"), r, 0); layout.addWidget(self.ed_length, r, 1); r+=1
        layout.addWidget(QtWidgets.QLabel("允许最大错口量 (mm)"), r, 0); layout.addWidget(self.ed_max_gap_allow, r, 1); r+=1

        self.btn_analyze = QtWidgets.QPushButton("分析与建议")
        self.btn_analyze.clicked.connect(self.on_analyze)
        layout.addWidget(self.btn_analyze, r, 0, 1, 3); r+=1

        self.txt_tol = QtWidgets.QTextEdit(); self.txt_tol.setReadOnly(True)
        layout.addWidget(self.txt_tol, r, 0, 1, 3)

    def on_analyze(self):
        fit_map = {"clearance(间隙)":"clearance","interference(过盈)":"interference","transition(过渡)":"transition"}
        fit_type = fit_map[self.cb_fit.currentText()]
        hole_min = self._f(self.ed_hole_min.text())
        hole_max = self._f(self.ed_hole_max.text())
        shaft_min = self._f(self.ed_shaft_min.text())
        shaft_max = self._f(self.ed_shaft_max.text())
        angle_tol = self._f(self.ed_angle_tol.text())
        L = self._f(self.ed_length.text())
        max_gap_allow = self._f(self.ed_max_gap_allow.text())

        # Fit decision at ref section
        fit_decision = clearance_fit_check(hole_min, hole_max, shaft_min, shaft_max)

        # Simulate worst-case angle mismatch = angle_tol * 2? (full angle ±tol => worst relative diff is 2*tol between parts)
        worst_delta_alpha = (angle_tol or 0.0) * 2.0 if angle_tol is not None else 0.0

        sim = contact_estimation(L or 0.0, worst_delta_alpha, max_gap_allow)
        suggest = suggest_angle_tolerance(L or 0.0, max_gap_allow or 0.0)

        report_lines = []
        report_lines.append("— 公差/接触分析 —")
        report_lines.append(f"参考截面配合判定: {fit_decision}")
        report_lines.append(f"最不利角度差(全角): ±{worst_delta_alpha:.6f} deg")
        report_lines.append(f"预测错口量: {sim.get('predicted_gap')} mm")
        report_lines.append(f"接触率估计: {round((sim.get('contact_ratio') or 0)*100,1)}%")
        report_lines.append(f"状态: {sim.get('status')} (与允许错口={max_gap_allow} mm 对比)")
        if suggest:
            report_lines.append(f"建议角度公差(全角, 双向±): ±{suggest:.6f} deg  (基于允许错口)")
        else:
            report_lines.append("建议角度公差: 输入的 L 或 允许错口无效，无法反推。")

        self.tol_cache = {
            "fit_type": fit_type,
            "hole_min": hole_min, "hole_max": hole_max,
            "shaft_min": shaft_min, "shaft_max": shaft_max,
            "fit_decision": fit_decision,
            "angle_tol_deg": angle_tol,
            "angle_tol_suggest_deg": suggest
        }
        self.sim_cache = sim
        self.txt_tol.setPlainText("\n".join(report_lines))

    def _f(self, s):
        try:
            return float(s)
        except:
            return None

    # ---------- Report Tab ----------
    def _init_report_tab(self):
        layout = QtWidgets.QVBoxLayout(self.tab_report)
        self.ed_project = QtWidgets.QLineEdit()
        self.ed_project.setPlaceholderText("项目/产品名称（可选）")
        layout.addWidget(self.ed_project)

        self.btn_export = QtWidgets.QPushButton("导出PDF报告")
        self.btn_export.clicked.connect(self.on_export_report)
        layout.addWidget(self.btn_export)

        self.txt_report = QtWidgets.QTextEdit(); self.txt_report.setReadOnly(True)
        self.txt_report.setPlainText("提示：请先在前两页完成计算与分析，然后在此导出PDF报告。")
        layout.addWidget(self.txt_report)

    def on_export_report(self):
        geom = getattr(self, "geom_cache", {})
        tol = getattr(self, "tol_cache", {})
        sim = getattr(self, "sim_cache", {})

        meta = {
            "project": self.ed_project.text().strip(),
            "date": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "version": "1.0"
        }
        fn, _ = QtWidgets.QFileDialog.getSaveFileName(self, "保存PDF", "ConeFit_Report.pdf", "PDF Files (*.pdf)")
        if not fn:
            return
        try:
            gen_pdf(fn, meta, geom, tol, sim)
            self.txt_report.setPlainText(f"报告已导出：{fn}")
        except Exception as e:
            QtWidgets.QMessageBox.critical(self, "错误", f"导出失败：{e}")

def main():
    app = QtWidgets.QApplication(sys.argv)
    w = MainWindow()
    w.show()
    sys.exit(app.exec_())

if __name__ == "__main__":
    main()


# Cone Fit Designer (圆锥配合设计计算)

## 快速开始（Windows）
1. 安装 Python 3.10+（若仅用 EXE 可跳过）。
2. 双击 `build.bat`（首次会创建虚拟环境并安装依赖），等待生成 `dist/ConeFitDesigner.exe`。
3. 运行 `ConeFitDesigner.exe`，菜单“帮助”可打开 `manual.pdf`。

## 功能
- 几何互算（D、d、L、锥度比、顶角）
- 公差/接触快速评估（错口量、接触率、角度公差建议）
- PDF 报告导出（reportlab）
- 示例方案 `src/data/sample_input.json`

## 目录
- `src/` 源码（PyQt5 GUI）
- `tools/generate_manual.py` 从 `manual.md` 生成 `manual.pdf`
- `build.bat` 一键打包（PyInstaller）
- `requirements.txt` 依赖列表

> 说明：接触率/错口量采用简化启发式模型，用于早期设计筛选；最终以蓝点与三坐标检测为准。

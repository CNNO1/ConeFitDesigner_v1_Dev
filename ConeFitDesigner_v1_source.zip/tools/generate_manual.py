
import os
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas
from reportlab.lib.units import mm

def md_to_lines(md_path):
    with open(md_path, "r", encoding="utf-8") as f:
        text = f.read()
    # Very naive: strip markdown headings and return plain lines
    lines = []
    for line in text.splitlines():
        line = line.strip()
        if line.startswith("#"):
            line = line.lstrip("# ").strip()
        lines.append(line)
    return lines

def write_pdf(pdf_path, lines):
    c = canvas.Canvas(pdf_path, pagesize=A4)
    W, H = A4
    x, y = 20*mm, H-20*mm
    c.setFont("Helvetica-Bold", 14); c.drawString(x, y, "圆锥配合设计计算软件 使用说明"); y -= 10*mm
    c.setFont("Helvetica", 10)
    for line in lines:
        if y < 20*mm:
            c.showPage()
            y = H-20*mm
            c.setFont("Helvetica", 10)
        c.drawString(x, y, line)
        y -= 6*mm
    c.showPage()
    c.save()

if __name__ == "__main__":
    root = os.path.dirname(os.path.dirname(__file__))
    md_path = os.path.join(root, "manual.md")
    out_pdf = os.path.join(root, "src", "resources", "manual.pdf")
    os.makedirs(os.path.dirname(out_pdf), exist_ok=True)
    lines = md_to_lines(md_path)
    write_pdf(out_pdf, lines)
    print("manual.pdf 生成于：", out_pdf)
